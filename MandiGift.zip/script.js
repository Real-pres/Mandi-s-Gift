const songs = ["Silent Running", "Norweigan Wood", "Starboy", "7 Rings", "Breakfast In America"];

const tssongs = [new Audio('sr.mp3'), new Audio('nw.mp3'), new Audio('sb.mp3'), new Audio('ag.mp3'), new Audio('bia.mp3')];

let lastplayed = 0;

songs.forEach((song, index) => {
    console.log("Index: " + index + " Playlist Name: " + song);

    const songlist = document.getElementById('songlist');

    const div = document.createElement('div');

    div.className = 'songdiv';
    div.id = song;
    div.innerHTML = song;

    div.onclick = function() {

        tssongs[lastplayed].pause();
        tssongs[lastplayed].currentTime = 0;

        console.log(song, "clicked");
        div.style.color = '#A0361F';
        console.log(song + " pressed!");
        tssongs[index].play();

        lastplayed = index; 

    };

    songlist.appendChild(div);
    
});